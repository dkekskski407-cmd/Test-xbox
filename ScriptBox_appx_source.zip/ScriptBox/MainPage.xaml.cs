using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using MoonSharp.Interpreter;
using System;
using System.Threading.Tasks;

namespace ScriptBox
{
    public sealed partial class MainPage : Page
    {
        private Script _lua;

        public MainPage()
        {
            this.InitializeComponent();
            InitLua();
        }

        private void InitLua()
        {
            _lua = new Script(CoreModules.Preset_Complete);

            _lua.Options.DebugPrint = s =>
            {
                var ignored = Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                {
                    OutputTextBox.Text += s + "\n";
                });
            };

            _lua.Globals["cs_show"] = (Action<string>)((msg) =>
            {
                var ignored = Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                {
                    OutputTextBox.Text += "[cs_show] " + msg + "\n";
                });
            });
        }

        private async void BtnRun_Click(object sender, RoutedEventArgs e)
        {
            OutputTextBox.Text = "";
            var code = ScriptTextBox.Text;

            await Task.Run(() =>
            {
                try
                {
                    var res = _lua.DoString(code);
                    if (res != null && res.Type != DataType.Nil)
                    {
                        var txt = res.ToPrintString();
                        var ignored = Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                        {
                            OutputTextBox.Text += "[ret] " + txt + "\n";
                        });
                    }
                }
                catch (InterpreterException ex)
                {
                    var ignored = Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                    {
                        OutputTextBox.Text += "[erro] " + ex.DecoratedMessage + "\n";
                    });
                }
                catch (Exception ex)
                {
                    var ignored = Windows.ApplicationModel.Core.CoreApplication.MainView.CoreWindow.Dispatcher.RunAsync(Windows.UI.Core.CoreDispatcherPriority.Normal, () =>
                    {
                        OutputTextBox.Text += "[fatal] " + ex.Message + "\n";
                    });
                }
            });
        }

        private void BtnLoadExample_Click(object sender, RoutedEventArgs e)
        {
            ScriptTextBox.Text = "print(\"Hello from Lua!\")\ncs_show(\"Mensagem do C#\")\nreturn 123";
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            ScriptTextBox.Text = "";
            OutputTextBox.Text = "";
        }
    }
}
