using Windows.UI.Xaml;

namespace ScriptBox
{
    sealed partial class App : Application
    {
        public App()
        {
            this.InitializeComponent();
        }

        protected override void OnLaunched(Windows.ApplicationModel.Activation.LaunchActivatedEventArgs e)
        {
            var root = new MainPage();
            Window.Current.Content = root;
            Window.Current.Activate();
        }
    }
}
